#loading in libraries
library("ggplot2")
library("dplyr")
library("Ecdat")

head(Cigarette)

#create a boxplot of the average # of packs per capita by state

ggplot(Cigarette, aes(x = state, y = packpc)) + geom_boxplot()

#Which states have the highest number of packs? which have the lowest?

Cigarette %>% group_by(state) %>% summarise(Mean = mean(packpc)) %>% arrange(Mean)

Cigarette %>% group_by(state) %>% summarise(Mean = mean(packpc)) %>% arrange(desc(Mean))

#KY and NH have the highest, UT, NM, CA have the lowest

#Find median over all states for number of packs per capita for each year

CigMedian <- Cigarette %>% select(year, state, packpc)

MedianDF <- CigMedian %>% group_by(year) %>% summarise(Median = median(packpc))

#plot this median value for years 1985-1995

unique(Cigarette$year)

ggplot(MedianDF, aes(x = year, y = Median)) +  geom_point()

#create a scatter plot of price per pack vs. number of packs per capita for all states and years

ggplot(Cigarette, aes(x = avgprs, y = packpc)) + geom_point() +geom_smooth(method=lm)

#the two variables are negatively correlated

cor.test(Cigarette$avgprs, Cigarette$packpc, method = "pearson", use = "complete.obs")

#change the scatter plot to show the points for each year in a different color.

ggplot(Cigarette, aes(x = avgprs, y = packpc, color = year)) +
geom_point() + geom_smooth(method=lm)

#do a linear regression

regression <- lm(avgprs~packpc, Cigarette)
summary(regression)

#how much variability does the line explain?
# 34% of the variability

#adjust the price of a pack of cig for inflation by dividing the avgprs variable by the cpi variable

inflation <- Cigarette %>% mutate(InflationPrice = avgprs / cpi)

#Create an adjusted price for each row, then redo the scatter plot and linear regression using this adjusted price


ggplot(inflation, aes(x= InflationPrice, y= packpc)) + geom_point()  + geom_smooth(method=lm)
ggplot(inflation, aes(x= InflationPrice, y= packpc, color=year)) + geom_point()  + geom_smooth(method=lm)
regressionInflat <- lm(cpi~InflationPrice, inflation)
summary(regressionInflat)

#Create data frame with just the rows from 1985 and a second data from from 1995

row1985 <- Cigarette %>% filter(year == 1985)

row1995 <- Cigarette %>% filter(year == 1995)

#from each of these data frames, get a vector of the number of packs per capita.

ppc1985 <- row1985$packpc
ppc1995 <- row1995$packpc

#paired t-test to see if the number of packspc change over time

t.obj <- t.test(ppc1985, ppc1995, paired = TRUE)
t.obj

#the p-value shows the number of packs per capita in 1995 was very significantly different than the number of packs per capita in 1985

#does the state population correlate to the packpc every year in all states?

library("PerformanceAnalytics")
library("corrplot")

cor.test(Cigarette$pop, Cigarette$packpc, method = "pearson", use = "complete.obs")


Cigarette_quant <- Cigarette [, c(4,5)]

chart.Correlation(Cigarette_quant, histogram = FALSE, method = "pearson")

#lets make it more visually appealing with a correlation matrix

corr_matrix <- cor(Cigarette_quant)
corr_matrix

corrplot(corr_matrix, type = "upper",order = "hclust",p.mat = corr_matrix,sig.level = 0.001, insig = "blank")





